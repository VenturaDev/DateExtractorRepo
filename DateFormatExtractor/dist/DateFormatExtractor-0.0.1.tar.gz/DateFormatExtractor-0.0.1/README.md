This library offers an easy implementation for extracting the date format from an iterator (serie, pandas column, array, list, etc).

The method "extract_format" needs only the iterator as parameter.
It uses a list of known date formats that you can overwrite passing the optional argument list_date_formats.